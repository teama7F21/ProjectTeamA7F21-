// Canvas API is slow so have to have button click event to show the data

btnShowAssignments.onclick=function(){
  console.log("in CanvasAPI: " + calenderAssign)
  lblDisplayCanvas.value = calenderAssign[0].name
  lblDisplayCanvasDate.value = calenderAssign[0].due_at
}
HamburgerA.onclick=function(s){
  if (typeof(s) == "object")
       return
     else {
       switch(s) {
            case "Home Page":
                ChangeForm(HomePage)
                break
                   case "Weather":
                ChangeForm(WeatherAPI)
                break
                    case "Shopping List":
                ChangeForm(shoppingList)
       }  
       }
}
