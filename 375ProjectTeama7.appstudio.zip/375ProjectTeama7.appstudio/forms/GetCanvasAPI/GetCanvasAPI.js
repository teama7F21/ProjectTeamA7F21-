let calenderAssign 

function getCanvas() {
  let APIKey = "1117~3nmSfxL56lQ34ngL5wjRXvIdDlVrpsRrH6E9Vgri740cQRquOesKqZUtGL3voPnt"
  let corsAPIKey = "3260e5c6-382f-4275-93ac-54cbfcd3e6b5"
  const extraHeaders ={
    headers: new Headers({
      "Authorization": "Bearer " + APIKey,
      "x-cors-grida-api-key": corsAPIKey
      })
  }
  //let header = 'Authorization=Bearer 1117~3nmSfxL56lQ34ngL5wjRXvIdDlVrpsRrH6E9Vgri740cQRquOesKqZUtGL3voPnt'
  fetch('https://cors.bridged.cc/https://blueline.instructure.com/api/v1/courses/1168740/assignments?include[]=all_dates&order_by=due_at&per_page=200', extraHeaders)
    .then(function(resp) { return resp.json() }) // Convert data to json
    .then(function(data) {
        freeData(data) })
    .catch(function() {
    })
}

function freeData(apiDataC) {
  console.log(`${apiDataC[0].name}`)
  console.log(`${apiDataC[0].due_at}`)
  console.log("in free data: " + apiDataC)
  calenderAssign = apiDataC
}

btnLoadAPI.onclick=function(){
     getCanvas()
}

btnSeeCanvasData.onclick=function(){
  ChangeForm(CanvasAPI)
}
HamburgerC.onclick=function(s){
  if (typeof(s) == "object")
       return
     else {
       switch(s) {
            case "Home Page":
                ChangeForm(HomePage)
                break
                   case "Weather":
                ChangeForm(WeatherAPI)
                break
                    case "Shopping List":
                ChangeForm(shoppingList)
                break
       }  
       }
}