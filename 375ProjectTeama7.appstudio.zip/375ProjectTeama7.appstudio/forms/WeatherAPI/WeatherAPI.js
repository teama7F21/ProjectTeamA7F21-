let weather
let city = "Omaha"

function getWeather() {
  let key = 'd7badbe068cf5365bd653f12622a54c7'
  fetch('https://api.openweathermap.org/data/2.5/weather?q=' + city + '&units=imperial&appid=' + key)
    .then(function(resp) { return resp.json() }) // Convert data to json
    .then(function(data) {freeData2(data) })
    .catch(function() {
    })
}

function freeData2(apiData) {
  console.log(`in freeData2, main.temp is ${apiData.main.temp}`)
  weather = apiData
}

btnSubmitCity.onclick = function() {
  getWeather()
}

btnShowWeather.onclick = function() {
  ChangeForm(showWeather)
}

inptCity.onchange = function() {
  city = inptCity.value
}
HamburgerW.onclick=function(s){
  if (typeof(s) == "object")
       return
     else {
       switch(s) {
            case "Home Page":
                ChangeForm(HomePage)
                break
                   case "Canvas":
                ChangeForm(GetCanvasAPI)
                break
                    case "Shopping List":
                ChangeForm(shoppingList)
                break
       }  
       }
}
