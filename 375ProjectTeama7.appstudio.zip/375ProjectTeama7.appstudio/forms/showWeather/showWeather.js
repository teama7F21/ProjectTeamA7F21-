showWeather.onshow=function(){
  lblWeather.value = weather.main.temp
  console.log(`The weather for the city you input is ${weather.main.temp} degrees Farenheit.`)
}

HamburgerW2.onclick=function(s){
  if (typeof(s) == "object")
       return
     else {
       switch(s) {
            case "Home Page":
                ChangeForm(HomePage)
                break
                   case "Canvas":
                ChangeForm(GetCanvasAPI)
                break
                    case "Shopping List":
                ChangeForm(shoppingList)
                break
       }  
       }
}